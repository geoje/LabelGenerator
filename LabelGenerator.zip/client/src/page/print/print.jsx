import { Text } from "@mantine/core";

export default function Print() {
  return <Text>none</Text>;
}
