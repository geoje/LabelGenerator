export default function Design() {
  return <h1>Design</h1>;
}
